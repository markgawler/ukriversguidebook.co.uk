<?php
Proj4php::$defs["EPSG:102758"] = "+title=NAD 1983 StatePlane Wyoming West FIPS 4904 Feet +proj=tmerc +lat_0=40.5  +lon_0=-110.0833333333333 +x_0=800000  +y_0=100000  +k=0.999938 +a=6378137.0 +b=6356752.3141403 +to_meter=0.3048006096012192";
