<?php
/**
 * Author : Julien Moquet
 * 
 * Inspired by Proj4js from Mike Adair madairATdmsolutions.ca
 *                      and Richard Greenwood rich@greenwoodmap.com 
 * License: LGPL as per: http://www.gnu.org/copyleft/lesser.html 
 */
class proj4phpLongLat {

    public function init() {
        
    }

    public function forward( $pt ) {
        return $pt;
    }

    public function inverse( $pt ) {
        return $pt;
    }

}