<?php

/**
 * @version		0.1
 * @package		UKRGB - Map
 * @copyright	Copyright (C) 2012 The UK Rivers Guide Book, All rights reserved.
 * @author		Mark Gawler
 * @link		http://www.ukriversguidebook.co.uk
 * @license		License GNU General Public License version 2 or later
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>
<h1>The UK Rivers Guidebook</h1>

<p><?php echo $this->message; ?></p>
<ul>
<li>Article: <?php echo $this->data['article']; ?></li>
<li>Map: </li>
<li>Grede: </li>
</ul> 


