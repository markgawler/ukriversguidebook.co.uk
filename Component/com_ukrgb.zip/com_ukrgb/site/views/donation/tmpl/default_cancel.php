<?php
defined('_JEXEC') or die('Restricted access');
?>
<h1>Transaction Cancel</h1>

<h3>It apears you did not complete the payment</h3>
<p>Your transaction has not completed. Please log into your PayPal account to review details of this transaction.</p>
<p></p>
<p></p>
<p>Status: <?php echo $this->status; ?></p>

