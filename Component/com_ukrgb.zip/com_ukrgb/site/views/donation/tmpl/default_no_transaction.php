<?php
defined('_JEXEC') or die('Restricted access');
?>
<h1>Error!</h1>

<h3>Error!</h3>
<p></p>
