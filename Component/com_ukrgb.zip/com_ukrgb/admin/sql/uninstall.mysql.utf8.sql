DROP TABLE IF EXISTS `#__ukrgb_doantion`;
DROP TABLE IF EXISTS `#__ukrgb_maps`;
DROP TABLE IF EXISTS `#__ukrgb_riverguides`;