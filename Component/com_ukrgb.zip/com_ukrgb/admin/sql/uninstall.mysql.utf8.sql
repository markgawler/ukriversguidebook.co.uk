DROP TABLE IF EXISTS `#__ukrgb_doantion`;
