window.addEvent("domready", function() {
	// Create a new map instance
	var map = L.map('map');
	var id = 0;
	map.setView([51.505, -0.09], 12);
	
	
	for (i = 0 ;i < 10; i++){
		var marker = L.marker([51.5 + (i/100), -0.09+(i/100)],{draggable : true, title : "hello world!"}).addTo(map);
		marker.id = i;
		marker.on('click',function(e){
			alert(this.id)
			//this.setOpacity(0.5);
		});
	}
	
	
/*	var myAnchor = new Element('a', {
	    href: '#',
	    'class': 'speciallink',
	    html: 'Click me!',
	    //styles: {
	    //    display: 'block',
	    //    border: '1px solid black'
	    //},
	    events: {
	        click: function(){
	        	var m = $(this).id;
	            alert('clicked: ' +m);
//	        },
//	        mouseover: function(){
//	            alert('mouseovered');
	        }
	    },
	    id : '123'
	});
	marker.bindPopup(myAnchor);*/
	
	
	marker.on('dragend', function(e) {
		var ll = e.target.getLatLng();
		alert("draged" + ll);
	});
	
	map.on('click', function(e) {
		id = id +1;
		var marker = L.marker(e.latlng,{draggable : true}).addTo(map);
		//marker.bindPopup("<b>Hello world!</b><br>I am a popup.");
		marker.on('dragend', function(e) {
			var ll = e.target.getLatLng();
			alert("draged" + ll);
		});
		
		
		var myAnchor = new Element('a', {
		    href: '#',
		    'class': 'speciallink',
		    html: 'Click me!',
		    events: {
		        click: function(){
		        	var m = $(this).id;
		            alert('clicked: ' +m);
		        }
		    },
		    id : id
		});
		marker.bindPopup(myAnchor);
		
	});
	
	
	
	
	
	L.tileLayer('http://{s}.tile.cloudmade.com/9ad2029a7cff49ea8d3445b55352f445/997/256/{z}/{x}/{y}.png', {
		attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery Â© <a href="http://cloudmade.com">CloudMade</a>',
		maxZoom: 18
	}).addTo(map);
	
});