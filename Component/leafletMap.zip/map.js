var markers_group = {};
var mappoints = new Array();
var map = {};

window.addEvent("domready", function() {
	// Create a new map instance
	map = L.map('map');
	var id = 0;
	map.setView([51.505, -0.09], 12);
	
	markers_group = L.layerGroup().addTo(map);
	
	/*for (i = 0 ;i < 10; i++){
		var marker = L.marker([51.5 + (i/100), -0.09+(i/100)],{draggable : true, title : "hello world!"}).addTo(map);
		marker.id = i;
		marker.on('click',function(e){
			alert(this.id)
			//this.setOpacity(0.5);
		});
	}*/
	
	
/*	var myAnchor = new Element('a', {
	    href: '#',
	    'class': 'speciallink',
	    html: 'Click me!',
	    //styles: {
	    //    display: 'block',
	    //    border: '1px solid black'
	    //},
	    events: {
	        click: function(){
	        	var m = $(this).id;
	            alert('clicked: ' +m);
//	        },
//	        mouseover: function(){
//	            alert('mouseovered');
	        }
	    },
	    id : '123'
	});
	marker.bindPopup(myAnchor);*/
	
	//map.on('popupopen' ,function(e) {
	//	var marker = e.popup._source;
	//	id = marker.myid;
	//	alert ("Popup Open. Marker id: " + id);
	//});
	
	map.on('click', function(e) {
		id = id +1;
		console.log("New Maker: " + id)
		marker = L.marker(e.latlng,{draggable : true}).addTo(markers_group);
		marker.myid = id;
		//marker.mylable = "lable " + id;

		var form =  
			//'<fieldset><legend>Marker Details:</legend>'+
			'<form name="popupForm" onsubmit="return popupSubmit()">'+
			'<input type="hidden" name="id" value="'+marker.myid+'">' +
			'Lable: <input type="text" name="popupLable">'+
			  '<br>'+
	            '<input type="radio" name="pointType" value="typePutin">Put-In'+
	            '<br>'+
	            '<input type="radio" name="pointType" value="typeTakeout">Take-Out'+
	            '<br>'+
	            '<input type="radio" name="pointType" value="typeAlternateAccess" checked>Alternate Put-in/ Take-out'+
	            '<br>'+
            '<input type="submit" value="Submit">'+
            '</form>'
            //</fieldset>'
            //'<div style="text-align:center;"><button type="button" onclick="deletePoint()">Delete</button></div>';

            //'<div>'+
            //  '<div style="text-align:center;"><button type="button" onclick="cancelRegistration()">Cancel</button></div>'+
            //  '<div style="text-align:center;"><button type="button" onclick="insertUser()">Submit</button></div>'+
            //'</div>'+
		
		
		marker.bindPopup(form).openPopup();
		
		
		marker.on('dragend', function(e) {
			var ll = e.target.getLatLng();
			alert("draged" + ll);
		});
		
		marker.on('click',function(e){
			this.setOpacity(0.5);
			//alert(this.myid)
			var mp = mappoints[this.myid];
			if (mp != null){ 
				var f=document.forms["popupForm"];
				f["popupLable"].value = mp.lable;
				switch(mp.type){
				case "typePutin":
					f["pointType"][0].checked = true;
					break;
				case "typeTakeout":
					f["pointType"][1].checked = true;
					break;
				default:
					f["pointType"][2].checked = true;
				}
			}
		});
		
		/*
		var myAnchor = new Element('a', {
		    href: '#',
		    'class': 'speciallink',
		    html: 'Click me!',
		    events: {
		        click: function(){
		        	var m = $(this).id;
		            alert('clicked: ' +m);
		        }
		    },
		    id : id
		});
		marker.bindPopup(myAnchor);
		*/
		
		//if (id == 10){
		//	markers_group.eachLayer(function (layer) {
				//if (layer.myid > 5){
				//	layer.bindPopup('Hello I am ' + layer.myid);
			    //}
		//	});
		//}
		
	});
	
	L.tileLayer('http://{s}.tile.cloudmade.com/9ad2029a7cff49ea8d3445b55352f445/997/256/{z}/{x}/{y}.png', {
		attribution: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery Â© <a href="http://cloudmade.com">CloudMade</a>',
		maxZoom: 18
	}).addTo(map);
	
});


//  Popup Form submit action
function popupSubmit(){
	console.log('Submit');

	var f=document.forms["popupForm"];
	var l= f["popupLable"].value;
	var formid = f["id"].value;
	var t = f["pointType"];
	var v = 0;
	for (var c=0; c<t.length; c++){
		if (t[c].checked){v = t[c].value;};
	};
	console.log('Lable: '+ l );
	console.log('Id:    '+ formid);
	console.log('Type:  '+ v);
 
	
	mappoints[formid]= {
			lable: l,
			type: v};
	map.closePopup();
	return false;
}

function submitAction(){
	//alert ("Submitt");
	markers_group.clearLayers();
};

function deletePoint(){
	id = (this).myid;
	alert ("Delete: " + id);
};